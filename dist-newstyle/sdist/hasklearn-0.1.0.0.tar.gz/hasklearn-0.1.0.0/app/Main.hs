module Main where

main :: IO ()

putStrLn "Hello World"